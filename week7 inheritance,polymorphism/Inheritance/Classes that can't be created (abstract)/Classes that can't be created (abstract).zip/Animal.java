// An abstract Animal class
public abstract class Animal
{
    public abstract String greeting();
}
// and a method called greeting which returns a String.