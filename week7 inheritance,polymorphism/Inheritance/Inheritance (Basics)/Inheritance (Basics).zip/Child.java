public class Child extends Parent
{
}