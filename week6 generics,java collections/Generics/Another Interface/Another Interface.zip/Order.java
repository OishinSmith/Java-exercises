interface Order {
    boolean greaterThan(Order other);
}